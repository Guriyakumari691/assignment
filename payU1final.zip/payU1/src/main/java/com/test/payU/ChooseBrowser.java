package com.test.payU;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;

public class ChooseBrowser {

	WebDriver driver = null;
	Properties p = new Properties();

	public ChooseBrowser(WebDriver driver) {
		this.driver = driver;

	}

	public WebDriver openBrowser() throws IOException {
		// Read Data from properties file
		FileReader reader = new FileReader(
				System.getProperty("user.dir") + "\\src\\main\\java\\config\\config.properties");

		p.load(reader);
		if (p.getProperty("browserType").equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\Resources\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().deleteAllCookies();
			driver.manage().timeouts().pageLoadTimeout(20, TimeUnit.SECONDS);
			driver.get(p.getProperty("URL"));

		}

		
		 //For firefox else
		  if(p.getProperty("browserType").equalsIgnoreCase("firefox")) {
		  System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") +"\\Resources\\geckodriver.exe"); 
		  driver = new FirefoxDriver();
		   }
		  
		 //For InternetExplorerDriver else
		 if(p.getProperty("browserType").equals("IE")) {
		 System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") +"\\Resources\\IEDriverServer.exe"); 
		 driver = new InternetExplorerDriver();
		 }
		 
		
		return driver;
	}

	//@AfterClass
	public void tearDown() {
		driver.quit();

	}

	public void waitforElementtoload(int time) throws InterruptedException {
		Thread.sleep(time * 1000);
	}

}