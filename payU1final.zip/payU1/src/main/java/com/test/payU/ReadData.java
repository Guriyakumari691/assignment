package com.test.payU;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ReadData {
	
	public String getData(int rownum, int colnum) throws IOException {
		
		
		FileInputStream file = new FileInputStream(new File("C:\\Users\\guriya.kumari\\eclipse-workspace22\\payU1\\Resources\\test.xlsx"));
		//Create Workbook instance holding reference to .xlsx file
		XSSFWorkbook wb = new XSSFWorkbook(file);
		
		XSSFSheet sh = wb.getSheetAt(0);
		DataFormatter formatter = new DataFormatter(); //creating formatter using the default locale
		Cell cell1 = sh.getRow(rownum).getCell(colnum);
		String text = formatter.formatCellValue(cell1);
		
		return text;
		/*
		 * XSSFRow row =sh.getRow(rownum);
		 * 
		 * 
		 * Cell cell = row.getCell(colnum); return cell.toString();
		 */

	//System.out.println(	cell.toString());
			}
	
	
		}		
	

