package com.test.payU;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import org.openqa.selenium.support.ui.Select;


public class Payment_Page {
	
	WebDriver driver;
	public Payment_Page(WebDriver driver)
	{
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);
	}
	

	@FindBy(xpath="//input[@id='card-number1']")
	public WebElement cardNumber1;
	

	@FindBy(xpath="//input[@id='card-number2']")
	public WebElement cardNumber2;
	
	
	@FindBy(xpath="//input[@id='card-number3']")
	public WebElement cardNumber3;
	
	
	@FindBy(xpath="//input[@id='card-number4']")
	public WebElement cardNumber4;
	
	
	//Re-Enter Card Number 
	@FindBy(xpath="//input[@id='re-card-number1']")
	public WebElement input_recard_number1;
	
	
	@FindBy(xpath="//input[@id='re-card-number2']")
	public WebElement input_recard_number2;
	
	
	
	@FindBy(xpath="//input[@id='re-card-number3']")
	public WebElement input_recard_number3;
	
	
	@FindBy(xpath="//input[@id='re-card-number4']")
	public WebElement input_recard_number4;
	
	//Enter Email-ID
	@FindBy(xpath="//input[@id='email-id']")
	public WebElement input_emailid;
	
	//Enter Mobile Number
	@FindBy(xpath="//input[@id='mobile-number']")
	public WebElement input_MobileNo;
	
	//Enter Payment Amount
	@FindBy(xpath="//input[@id='payment-amount']")
	public WebElement input_payment_Amount;
	
	//Select Bank name from dropdown
	@FindBy(xpath="//*[@name='bank_id']")
	public WebElement select_dropdownBankName;
	
		
			
     //Click on submit button
	 @FindBy(xpath="//input[@id='btnSubmit']")
	 public WebElement input_submitBtn;
	
	 
	 //Enter card NUmber of payUbiz
	 @FindBy(xpath="//input[@name='ccard_number']")
     public WebElement input_payUbiz_card1;	 
	 
	 
	 @FindBy(xpath="//input[@name='ccard_number']")
     public WebElement input_payUbiz_card2;	
	 
	 
	 @FindBy(xpath="//input[@name='ccard_number']")
     public WebElement input_payUbiz_card3;	
	 
	 
	 @FindBy(xpath="//input[@name='ccard_number']")
     public WebElement input_payUbiz_card4;	 
	 
	 //Select Card Name
	 @FindBy(xpath="//input[@id='cname_on_card']")	
	 public WebElement input_cardName;
	 
	 //Enter Cvv number
	 @FindBy(xpath="//input[@id='ccvv_number']")	
	 public WebElement input_cvv;
	 
	 //Expiry DateMonth
	 @FindBy(xpath="//p//select[@id='cexpiry_date_month']")
	 public WebElement input_expirtDatemonth;
	 
	 //Expiry DateYear
	 @FindBy(xpath="//p//select[@id='cexpiry_date_year']")
	 public WebElement input_expirtDateYear;
	 
	 //Click on PayNow
	 @FindBy(xpath="(//input[@type='submit'])[1]")
	 public WebElement input_payNow;
	 
	 //Enter simulator Text
	 @FindBy(xpath="//input[@name='password']")
	 public WebElement input_simulatorText;
	 
	 //Click on PayNow
	 @FindBy(xpath="//input[@id='submitBtn']")
	 public WebElement input_payNowbtn;
	 
	//Verify Payment screen Success message
	 @FindBy(xpath="//div[contains(@class,'responseValueCls')])[1]")
	 public WebElement successMsg;
	 

}