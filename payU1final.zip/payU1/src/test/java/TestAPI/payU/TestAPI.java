package TestAPI.payU;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;

import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.ResponseSpecification;


public class TestAPI 
{
	
	@Test
	public  void getResponse()
	{
		 

		given().
		
			    when().
		        get("https://www.getpostman.com/collections/371172dd468738ce5c4c").then().
	        assertThat().
	       statusCode(200);
	    
	      
		
	}
}
