package testProjPayU;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.test.payU.ChooseBrowser;
import com.test.payU.Payment_Page;
import com.test.payU.ReadData;
import com.test.payU.TakeScreenShot;


public class TC_001  {
	public WebDriver driver ;

	@Test 
	public void test() throws IOException, Exception
	{
		try {
		ReadData rd = new ReadData();
		String cardnumber1= rd.getData(0, 1);
		String cardnumber2= rd.getData(1, 1);
		String cardnumber3= rd.getData(2, 1);
		String cardnumber4= rd.getData(3, 1);
		String recard_number1= rd.getData(4, 1);
		String recard_number2= rd.getData(5, 1);
		String recard_number3= rd.getData(6, 1);
		String recard_number4= rd.getData(7, 1);
		String emailid= rd.getData(8, 1);
		String MobileNo= rd.getData(9, 1);
		String payment_Amount= rd.getData(10, 1);
		String BankName= rd.getData(11, 1);
		
		String payUbiz_card1= rd.getData(12, 1);
		String payUbiz_card2= rd.getData(13, 1);
		String payUbiz_card3= rd.getData(14, 1);
		String payUbiz_card4= rd.getData(15, 1);
		String cardName= rd.getData(16, 1);
		String cvv= rd.getData(17, 1);
		String expirtDatemonth= rd.getData(18, 1);
		String expirtDateYear= rd.getData(19, 1);
		String simulatorText= rd.getData(20, 1);
				
		//Choose Browser and open application URL
		ChooseBrowser chooseBrowser = new ChooseBrowser(driver);
		driver = chooseBrowser.openBrowser();
		
		//Creating required objects
		Payment_Page payment_Page = new Payment_Page(driver);
		
		//Enter card Number
		payment_Page.cardNumber1.sendKeys(cardnumber1);
		payment_Page.cardNumber2.sendKeys(cardnumber2);
		payment_Page.cardNumber3.sendKeys(cardnumber3);	
        payment_Page.cardNumber4.sendKeys(cardnumber4);	
        
        //Re-Enter Card Number
		payment_Page.input_recard_number1.sendKeys(recard_number1);
		payment_Page.input_recard_number2.sendKeys(recard_number2);
		payment_Page.input_recard_number3.sendKeys(recard_number3);
		payment_Page.input_recard_number4.sendKeys(recard_number4);
      
		//Enter Email Id
		payment_Page.input_emailid.sendKeys(emailid);

		//Enter Mobile Number
		payment_Page.input_MobileNo.sendKeys(MobileNo);
		
		//Enter Payment Amount
		payment_Page.input_payment_Amount.sendKeys(payment_Amount);
		
		//select Bank Name
		Select bank =new Select(payment_Page.select_dropdownBankName);
		bank.selectByValue(BankName);
		
		//Click on submit button
		payment_Page.input_submitBtn.click();
		
		//Enter CardNumber payUbiz
		payment_Page.input_payUbiz_card1.sendKeys(payUbiz_card1);
		payment_Page.input_payUbiz_card2.sendKeys(payUbiz_card2);
		payment_Page.input_payUbiz_card3.sendKeys(payUbiz_card3);
		payment_Page.input_payUbiz_card4.sendKeys(payUbiz_card4);
		
		//Select Card name
		payment_Page.input_cardName.sendKeys(cardName);
		
		//Enter cvv Number
		payment_Page.input_cvv.sendKeys(cvv);
		
		//select DateMonth
		Select month =new Select(payment_Page.input_expirtDatemonth);
		month.selectByVisibleText(expirtDatemonth);

		
		
		//Select DateYear
		Select year =new Select(payment_Page.input_expirtDateYear);
		year.selectByValue(expirtDateYear);
		
		
		//Click ON PayNow
		payment_Page.input_payNow.click();
		
		Thread.sleep(4000);
		//Enter Simulator Text
		payment_Page.input_simulatorText.sendKeys(simulatorText);
		
		//Click On PayNow
		payment_Page.input_payNowbtn.click();
		
		//Verify Payment screen Success message		
		Assert.assertTrue(payment_Page.successMsg.getText().equalsIgnoreCase("Success"), "Success not shown.");
		}
		
		catch (Exception e)
		{
			//capture screenshot
			TakeScreenShot tg = new TakeScreenShot();
			tg.ScrShot(driver);
			
			
		}
		} 
} 